import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import type { Member, PaginatedResult } from "@/types";
import type { MemberInput } from "@/lib/validations/member";
import { logActivity } from "@/services/workflow.service";

export async function listMembers(params: { page?: number; pageSize?: number; search?: string; status?: string; branchId?: string | null } = {}): Promise<PaginatedResult<Member>> {
  const { page = 1, pageSize = 10, search, status = "active", branchId } = params;
  const supabase = await createClient();
  let query = supabase.from("members").select("id, member_code, machine_user_id, full_name, gender, date_of_birth, phone, email, profile_photo_url, fitness_goal, height_cm, weight_kg, status, branch_id, created_at", { count: "exact" });
  if (search) query = query.or(`full_name.ilike.%${search.replace(/[%_,]/g, "")}%,member_code.ilike.%${search.replace(/[%_,]/g, "")}%,phone.ilike.%${search.replace(/[%_,]/g, "")}%`);
  if (status && status !== "all") query = query.eq("status", status);
  if (branchId) query = query.eq("branch_id", branchId);
  const from = (page - 1) * pageSize;
  const { data, count, error } = await query.order("created_at", { ascending: false }).range(from, from + pageSize - 1);
  if (error) throw new Error(error.message);
  const total = count ?? 0;
  return { data: (data ?? []) as Member[], page, pageSize, total, totalPages: Math.ceil(total / pageSize) };
}

export async function createMember(input: MemberInput, performedBy?: string, tenantId?: string | null) {
  const supabase = await createClient();
  const { data: branch, error: branchError } = await supabase
    .from("branches")
    .select("id, tenant_id")
    .eq("id", input.branch_id)
    .maybeSingle();
  if (branchError) throw new Error(branchError.message);
  if (!branch) throw new Error("Selected branch was not found.");
  if (tenantId && branch.tenant_id && branch.tenant_id !== tenantId) throw new Error("Selected branch does not belong to your organization.");

  const resolvedTenantId = branch.tenant_id ?? tenantId ?? null;
  if (!resolvedTenantId) throw new Error("Selected branch is missing tenant ownership.");

  if (!branch.tenant_id && tenantId) {
    const admin = createAdminClient();
    const { error: backfillError } = await admin
      .from("branches")
      .update({ tenant_id: tenantId })
      .eq("id", branch.id)
      .is("tenant_id", null);
    if (backfillError) throw new Error(backfillError.message);
  }

  const payload = { ...input, tenant_id: resolvedTenantId };
  const { data: inserted, error } = await supabase.from("members").insert(payload).select().single();
  if (error) throw new Error(error.message);

  let data = inserted;
  if (!data.machine_user_id) {
    const { data: patched, error: patchError } = await supabase
      .from("members")
      .update({ machine_user_id: data.member_code })
      .eq("id", data.id)
      .select()
      .single();
    if (patchError) throw new Error(patchError.message);
    data = patched;
  }

  await logActivity({
    performedBy: performedBy ?? null,
    branchId: data.branch_id,
    action: "member_created",
    entityType: "member",
    entityId: data.id,
    description: "Member created",
    metadata: { member_code: data.member_code, biometric_user_id: data.machine_user_id, status: data.status },
  });
  return data;
}

export async function updateMember(id: string, input: Partial<MemberInput>, performedBy?: string) {
  const supabase = await createClient();
  const { data, error } = await supabase.from("members").update(input).eq("id", id).select().single();
  if (error) throw new Error(error.message);
  await logActivity({
    performedBy: performedBy ?? null,
    branchId: data.branch_id,
    action: "member_updated",
    entityType: "member",
    entityId: data.id,
    description: "Member updated",
    metadata: input as Record<string, string | number | boolean | null>,
  });
  return data;
}
