"use server";

import { revalidatePath } from "next/cache";
import { requireUser } from "@/lib/auth";
import {
  deactivateMember,
  renewMembership,
  assignTrainer,
  assignDietician,
} from "@/services/member-extended.service";
import { updateMember } from "@/services/member.service";
import { memberSchema } from "@/lib/validations/member";

export async function deactivateMemberAction(
  memberId: string,
): Promise<{ error?: string }> {
  const profile = await requireUser(["admin", "manager", "reception"]);
  try {
    await deactivateMember(memberId, profile.id);
  } catch (err) {
    return { error: err instanceof Error ? err.message : "Could not deactivate member." };
  }
  revalidatePath("/admin/members");
  revalidatePath(`/admin/members/${memberId}`);
  revalidatePath("/reception/members");
  return {};
}

export type RenewState = { error?: string; success?: string };

export async function renewMembershipAction(
  _: RenewState,
  formData: FormData,
): Promise<RenewState> {
  const profile = await requireUser(["admin", "manager", "reception"]);

  const memberId = formData.get("member_id") as string;
  const branchId = formData.get("branch_id") as string;
  const planId = formData.get("plan_id") as string;
  const startDate = formData.get("start_date") as string;
  const price = Number(formData.get("price") ?? 0);
  const discount = Number(formData.get("discount_amount") ?? 0);
  const gst = Number(formData.get("gst_amount") ?? 0);
  const total = Number(formData.get("total_amount") ?? 0);
  const remarks = (formData.get("remarks") as string | null) ?? null;

  if (!memberId || !branchId || !planId || !startDate)
    return { error: "All fields are required." };
  if (total <= 0) return { error: "Total amount must be greater than zero." };

  try {
    await renewMembership({
        memberId,
        branchId,
        tenantId: profile.tenant_id,
        planId,
      startDate,
      price,
      discountAmount: discount,
      gstAmount: gst,
      totalAmount: total,
      createdBy: profile.id,
      remarks,
    });
  } catch (err) {
    return { error: err instanceof Error ? err.message : "Renewal failed." };
  }

  revalidatePath(`/admin/members/${memberId}`);
  revalidatePath("/admin/members");
  return { success: "Membership renewed successfully." };
}

export type AssignTrainerState = { error?: string; success?: string };

export async function assignTrainerAction(
  memberId: string,
  trainerId: string | null,
): Promise<AssignTrainerState> {
  const profile = await requireUser(["admin", "manager", "reception"]);
  if (!profile.tenant_id) return { error: "Your account is not linked to an organization." };
  if (!memberId) return { error: "Member ID is required." };

  const supabase = await (await import("@/lib/supabase/server")).createClient();
  const { data: member, error: memberError } = await supabase
    .from("members")
    .select("id, branch_id, tenant_id")
    .eq("id", memberId)
    .eq("tenant_id", profile.tenant_id)
    .maybeSingle();
  if (memberError || !member) return { error: "Member not found in your organization." };
  if (profile.role?.slug === "reception" && member.branch_id !== profile.branch_id) {
    return { error: "Reception staff can assign trainers only in their assigned branch." };
  }

  if (trainerId) {
    const { data: trainer, error: trainerError } = await supabase
      .from("trainers")
      .select("id, branch_id, status")
      .eq("id", trainerId)
      .eq("status", "active")
      .maybeSingle();
    if (trainerError || !trainer) return { error: "Selected trainer is not active or available." };
    if (trainer.branch_id !== member.branch_id) return { error: "Selected trainer does not belong to this member's branch." };
    const { data: trainerBranch } = await supabase
      .from("branches")
      .select("id")
      .eq("id", trainer.branch_id)
      .eq("tenant_id", profile.tenant_id)
      .eq("status", "active")
      .maybeSingle();
    if (!trainerBranch) return { error: "Selected trainer is outside your organization." };
  }

  try {
    await assignTrainer(member.id, trainerId, profile.id);
  } catch (err) {
    return { error: err instanceof Error ? err.message : "Assignment failed." };
  }
  const base = profile.role?.slug === "reception" ? "/reception" : "/admin";
  revalidatePath(`${base}/members/${member.id}`);
  revalidatePath(`${base}/members`);
  return { success: trainerId ? "Trainer assigned." : "Trainer assignment removed." };
}
export async function assignDieticianAction(memberId: string, dieticianId: string | null): Promise<AssignTrainerState> {
  const profile = await requireUser(["admin", "manager", "reception"]);
  try {
    await assignDietician(memberId, dieticianId, profile.id);
  } catch (err) {
    return { error: err instanceof Error ? err.message : "Assignment failed." };
  }
  revalidatePath(`/admin/members/${memberId}`);
  revalidatePath(`/reception/members/${memberId}`);
  revalidatePath("/admin/members");
  revalidatePath("/reception/members");
  return { success: "Dietician assigned." };
}

export type UpdateState = { error?: string; fields?: Record<string, string[]> };

export async function updateMemberFullAction(
  _: UpdateState,
  formData: FormData,
): Promise<UpdateState> {
  const profile = await requireUser(["admin", "manager", "reception"]);
  const id = formData.get("id") as string;
  if (!id) return { error: "Member ID is missing." };

  const raw = Object.fromEntries(formData);
  const { id: _id, ...rest } = raw;
  void _id;

  const parsed = memberSchema.partial().safeParse({
    ...rest,
    height_cm: rest.height_cm || null,
    weight_kg: rest.weight_kg || null,
    date_of_birth: rest.date_of_birth || null,
    email: rest.email || null,
    assigned_trainer_id: rest.assigned_trainer_id || null,
  });

  if (!parsed.success)
    return {
      error: "Review the highlighted fields.",
      fields: parsed.error.flatten().fieldErrors as Record<string, string[]>,
    };

  try {
    await updateMember(id, parsed.data, profile.id);
  } catch (err) {
    return { error: err instanceof Error ? err.message : "Update failed." };
  }

  revalidatePath(`/admin/members/${id}`);
  revalidatePath("/admin/members");
  return {};
}

// ─── Send Renewal Notification ────────────────────────────────────────────────

/** Renewal reminders are generated by the protected expiry job, never manually. */
export async function sendRenewalNotificationAction(): Promise<{ error?: string }> {
  await requireUser(["admin", "manager", "reception"]);
  return { error: "Renewal notifications are generated from real membership expiry events." };
}
export async function checkInMemberAction(memberId: string): Promise<{ error?: string; success?: string }> {
  const profile = await requireUser(["admin", "manager", "reception"]);
  const supabase = await (await import("@/lib/supabase/server")).createClient();
  const { data: member, error: memberError } = await supabase
    .from("members")
    .select("id, branch_id")
    .eq("id", memberId)
    .maybeSingle();

  if (memberError || !member) return { error: "Member not found." };
  if (profile.branch_id && member.branch_id !== profile.branch_id) return { error: "This member belongs to another branch." };

  const today = new Date().toISOString().slice(0, 10);
  const { error } = await supabase.from("attendance").insert({
    member_id: member.id,
    branch_id: member.branch_id,
    device_id: "manual-dashboard",
    machine_user_id: profile.id,
    attendance_date: today,
    entry_time: new Date().toISOString(),
    source: "manual_dashboard",
  });

  if (error?.code === "23505") return { error: "This member is already checked in today." };
  if (error) return { error: error.message };

  revalidatePath("/admin/members");
  revalidatePath(`/admin/members/${memberId}`);
  revalidatePath("/reception/members");
  return { success: "Member checked in." };
}
