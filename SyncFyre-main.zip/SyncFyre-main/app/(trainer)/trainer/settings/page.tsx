import { PersonalSettingsForm } from "@/components/settings/personal-settings-form";
import { requireUser } from "@/lib/auth";

export default async function TrainerSettingsPage() {
  const profile = await requireUser(["trainer", "dietician", "diet-planner", "diet_planner"]);

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <div>
        <h1 className="text-2xl font-bold">Personal settings</h1>
        <p className="text-sm text-muted-foreground">Update your personal contact details.</p>
      </div>
      <PersonalSettingsForm
        title="Basic information"
        description="Update the profile details shown in the trainer and dietitian portals."
        fullName={profile.full_name}
        phone={profile.phone}
      />
    </div>
  );
}
